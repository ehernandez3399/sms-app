# SMS App

## Setup

1. Copy `.env.example` to `.env` and fill in your credentials.
2. Run `npm install`.
3. Start the server:
   - Development: `npm run dev`
   - Production: `npm start`

## Folder Structure

